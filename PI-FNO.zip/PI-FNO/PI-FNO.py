import argparse, os, time, math, random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt

def safe_percentile(arr, lo=2, hi=98):
    a = np.asarray(arr, float)
    a = a[np.isfinite(a)]
    if a.size == 0: return 0.0, 1.0
    return np.percentile(a, lo), np.percentile(a, hi)

def pretty(Z, mask=None, title="", vmin=None, vmax=None, fname="out.png", cmap="turbo"):
    Z = np.array(Z, dtype=float)
    if mask is not None:
        Z = np.where(mask > 0.5, Z, np.nan)  
    plt.figure(figsize=(6,6))
    im = plt.imshow(Z.T, origin="lower", interpolation="nearest", vmin=vmin, vmax=vmax, cmap=cmap)
    im.cmap.set_bad("white")
    plt.colorbar(im)
    plt.title(title)
    plt.xticks([]); plt.yticks([])
    plt.tight_layout(); plt.savefig(fname, dpi=160); plt.close()

class SpectralConv2d(nn.Module):
    def __init__(self, in_c, out_c, modes):
        super().__init__()
        self.mx = self.my = modes
        scale = 1.0 / (in_c * out_c)
        self.wr = nn.Parameter(scale * torch.randn(in_c, out_c, self.mx, self.my))
        self.wi = nn.Parameter(scale * torch.randn(in_c, out_c, self.mx, self.my))

    def forward(self, x):  
        B, C, Nx, Ny = x.shape
        x_ft = torch.fft.rfft2(x, norm="ortho")
        x_fr = torch.view_as_real(x_ft)  
        Kx = min(self.mx, x_fr.shape[2]); Ky = min(self.my, x_fr.shape[3])

        out = torch.zeros(B, self.wr.shape[1], x_fr.shape[2], x_fr.shape[3], 2,
                          device=x.device, dtype=x.dtype)
        a_r, a_i = x_fr[...,0], x_fr[...,1]
        wr, wi = self.wr[...,:Kx,:Ky], self.wi[...,:Kx,:Ky]

        out_r = torch.einsum("bixy,ioxy->boxy", a_r[:,:,:Kx,:Ky], wr) - \
                torch.einsum("bixy,ioxy->boxy", a_i[:,:,:Kx,:Ky], wi)
        out_i = torch.einsum("bixy,ioxy->boxy", a_r[:,:,:Kx,:Ky], wi) + \
                torch.einsum("bixy,ioxy->boxy", a_i[:,:,:Kx,:Ky], wr)
        out[:,:,:Kx,:Ky,0] = out_r
        out[:,:,:Kx,:Ky,1] = out_i

        y = torch.fft.irfft2(torch.view_as_complex(out), s=(Nx,Ny), norm="ortho")
        return y

class FNO2d(nn.Module):
    def __init__(self, in_ch, out_ch, width=64, layers=4, modes=24):
        super().__init__()
        self.fc0 = nn.Linear(in_ch, width)
        self.convs = nn.ModuleList([SpectralConv2d(width, width, modes) for _ in range(layers)])
        self.ws    = nn.ModuleList([nn.Conv2d(width, width, 1) for _ in range(layers)])
        self.act   = nn.GELU()
        self.fc1   = nn.Linear(width, 128)
        self.fc2   = nn.Linear(128, out_ch)

    def forward(self, x):  # [B,C,Nx,Ny]
        B,C,Nx,Ny = x.shape
        x = x.permute(0,2,3,1)     
        x = self.fc0(x)
        x = x.permute(0,3,1,2)   
        for sc, w in zip(self.convs, self.ws):
            x = self.act(sc(x) + w(x))
        x = x.permute(0,2,3,1)
        x = self.act(self.fc1(x))
        x = self.fc2(x)
        x = x.permute(0,3,1,2)
        return x

# ---------- physics ops ----------
def grad_centered(u, h):
    ux = (F.pad(u,(0,0,1,1),mode='replicate')[:,:,2:,:] - F.pad(u,(0,0,1,1),mode='replicate')[:,:,:-2,:])/(2*h)
    uy = (F.pad(u,(1,1,0,0),mode='replicate')[:,:,:,2:] - F.pad(u,(1,1,0,0),mode='replicate')[:,:,:,:-2])/(2*h)
    return ux, uy

def div_centered(vx, vy, h):
    dvx = (F.pad(vx,(0,0,1,1),mode='replicate')[:,:,2:,:] - F.pad(vx,(0,0,1,1),mode='replicate')[:,:,:-2,:])/(2*h)
    dvy = (F.pad(vy,(1,1,0,0),mode='replicate')[:,:,:,2:] - F.pad(vy,(1,1,0,0),mode='replicate')[:,:,:,:-2])/(2*h)
    return dvx + dvy

def residual_iso(sigma, p, h, f=None):
    px, py = grad_centered(p, h)
    Jx = sigma * px
    Jy = sigma * py
    divJ = div_centered(Jx, Jy, h)
    return divJ if f is None else divJ + f

# ---------- args ----------
def get_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--u",    default=r"C:\Users\ja\Downloads\U_from_mat.npy")
    ap.add_argument("--mask", default=r"C:\Users\ja\Downloads\mask_from_mat.npy")
    ap.add_argument("--steps", type=int, default=3000)
    ap.add_argument("--modes", type=int, default=24)
    ap.add_argument("--width", type=int, default=64)
    ap.add_argument("--layers", type=int, default=4)
    ap.add_argument("--lr", type=float, default=1e-4)       
    ap.add_argument("--lam_pde", type=float, default=1.0)
    ap.add_argument("--lam_data", type=float, default=50.0)
    ap.add_argument("--lam_tv", type=float, default=0.1)
    ap.add_argument("--lam_bc", type=float, default=0.0)     
    ap.add_argument("--print_every", type=int, default=200)
    ap.add_argument("--seed", type=int, default=42)
    return ap.parse_args()

# ---------- main ----------
def main():
    args = get_args()
    torch.manual_seed(args.seed); np.random.seed(args.seed); random.seed(args.seed)

    # ----- load -----
    U = np.load(args.u).astype(np.float32)       # (H,W)
    M = np.load(args.mask).astype(np.float32)    # (H,W) in {0,1}
    finite = np.isfinite(U)
    M = (M * finite.astype(np.float32)).astype(np.float32)
    U[~finite] = 0.0
    inside = (M > 0.5)
    if inside.sum() > 0:
        p05, p95 = np.percentile(U[inside], [5, 95])
        scale = max(p95 - p05, 1e-6)
        U = (U - np.median(U[inside])) / scale
    else:
        med = np.nanmedian(U[np.isfinite(U)])
        U = (U - med) / (np.nanstd(U[np.isfinite(U)]) + 1e-6)

    H, W = U.shape
    h = 1.0 / max(H-1, 1)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    U_t = torch.from_numpy(U)[None,None].to(device)
    M_t = torch.from_numpy(M)[None,None].to(device)
    f_t = torch.zeros_like(U_t)
    valid_mask = (M_t > 0.5).float()

    # ----- models -----
    in_ch = 2  # [f, mask]      
    pnet = FNO2d(in_ch, 1, width=args.width, layers=args.layers, modes=args.modes).to(device)
    snet = FNO2d(in_ch, 1, width=args.width, layers=args.layers, modes=args.modes).to(device)

    def build_input():
        return torch.cat([f_t, M_t], dim=1)

    params = list(pnet.parameters()) + list(snet.parameters())
    opt = torch.optim.AdamW(params, lr=args.lr, weight_decay=1e-4)

    losses = []
    t0 = time.time()
    for it in range(1, args.steps+1):
        x = build_input()

        p_raw = pnet(x)
        p = torch.tanh(p_raw)                    

        sigma_raw = snet(x)
        sigma = torch.clamp(F.softplus(sigma_raw), 1e-6, 10.0)  

        res = residual_iso(sigma, p, h, f=f_t)
        loss_pde  = torch.mean((res ** 2) * valid_mask)
        loss_data = torch.mean(((p - U_t) ** 2) * valid_mask)
        sx, sy = grad_centered(sigma, h)
        loss_tv  = torch.mean((torch.abs(sx) + torch.abs(sy)) * valid_mask)

        

        loss = args.lam_pde*loss_pde + args.lam_data*loss_data + args.lam_tv*loss_tv 

        opt.zero_grad()
        if not torch.isfinite(loss):
            print(f"[{it}] WARNING: loss is not finite. data={loss_data.item():.3e}, pde={loss_pde.item():.3e}, tv={loss_tv.item():.3e}")
            break
        loss.backward()
        torch.nn.utils.clip_grad_norm_(params, 1.0)
        opt.step()

        if it % args.print_every == 0:
            print(f"[{it}/{args.steps}] L={loss.item():.3e} data={loss_data.item():.3e} "
                  f"pde={loss_pde.item():.3e} tv={loss_tv.item():.3e} bc={loss_bc.item():.3e}  {time.time()-t0:.1f}s")
            with torch.no_grad():
                s_min, s_max = sigma.min().item(), sigma.max().item()
                print(f"     sigma range: [{s_min:.3e}, {s_max:.3e}] | p range: [{p.min().item():.3e}, {p.max().item():.3e}]")

        if it % 50 == 0:
            losses.append([loss.item(), loss_data.item(), loss_pde.item(), loss_tv.item(), loss_bc.item()])

    with torch.no_grad():
        x = build_input()
        p = torch.tanh(pnet(x))
        sigma = torch.clamp(F.softplus(snet(x)), 1e-6, 10.0)

    p_np = p.squeeze().detach().cpu().numpy()
    s_np = sigma.squeeze().detach().cpu().numpy()

    vmin, vmax = safe_percentile(U[inside] if inside.sum()>0 else U, 2, 98)
    pretty(U,    M, "Experimental U (masked)", vmin, vmax, "exp_masked.png")
    pretty(p_np, M, "FNO Fitted p (masked)",   vmin, vmax, "p_fit.png")

    svmin, svmax = safe_percentile(s_np[inside] if inside.sum()>0 else s_np, 5, 95)
    pretty(s_np,  M, "Isotropic conductivity σ (masked)", svmin, svmax, "sigma_fit.png")

    if len(losses) > 0:
        L = np.array(losses)
        plt.figure(figsize=(6.4,3.2))
        plt.plot(L[:,0], label="total"); plt.plot(L[:,1], label="data")
        plt.plot(L[:,2], label="pde");   plt.plot(L[:,3], label="tv")
        if L.shape[1] > 4: plt.plot(L[:,4], label="bc")
        plt.yscale("log"); plt.legend(); plt.tight_layout()
        plt.savefig("loss_curve.png", dpi=160); plt.close()

    print("Saved: exp_masked.png, p_fit.png, sigma_fit.png, loss_curve.png")

if __name__ == "__main__":
    main()
