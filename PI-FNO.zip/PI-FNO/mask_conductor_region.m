Ch1_2D(abs(Ch1_2D) > 0.13) = 0;

% polygon corner points
xv = [31, 70, 40, 6];
yv = [16, 57, 81, 42];

% meshgrid for pixel coordinates
[xpix, ypix] = meshgrid(1:size(Ch1_2D,2), 1:size(Ch1_2D,1));

% mask using polygon
mask = inpolygon(xpix, ypix, xv, yv);

% apply mask
U_masked = Ch1_2D;
U_masked(~mask) = NaN;

% get bounding box
[y_idx, x_idx] = find(mask);
xmin = min(x_idx); xmax = max(x_idx);
ymin = min(y_idx); ymax = max(y_idx);

% crop to conductor region
U_conductor = U_masked(ymin:ymax, xmin:xmax);
mask_crop   = mask(ymin:ymax, xmin:xmax);

figure;
imagesc(U_conductor);
colorbar; axis image;
title('Masked Conductor Region');

save('conductor_data.mat','U_conductor','mask_crop');

% create normalized coordinate grid
[H, W] = size(U_conductor);
[x, y] = meshgrid(1:W, 1:H);

x_norm = (x - 1)/(W-1) * 2 - 1;   % → [-1,1]
y_norm = (y - 1)/(H-1) * 2 - 1;   % → [-1,1]

save('conductor_normalized.mat','U_conductor','mask_crop','x_norm','y_norm');
